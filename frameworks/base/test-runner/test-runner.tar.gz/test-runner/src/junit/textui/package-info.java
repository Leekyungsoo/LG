/**
 * Utility classes supporting the junit test framework.
 * {@hide}
 */
package junit.textui;